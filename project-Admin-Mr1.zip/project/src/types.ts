export interface LogEntry {
  id: string;
  timestamp: string;
  uid: string;
  action: string;
  amount: string;
  oldBalance: string;
  newBalance: string;
  status: 'success' | 'error';
  message?: string;
}

export interface ToastAlert {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}
