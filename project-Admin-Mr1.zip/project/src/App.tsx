import { useState } from 'react';
import Login from '@/components/Login';
import Layout from '@/components/Layout';
import AdminPanel from '@/components/AdminPanel';
import DiamondsPanel from '@/components/DiamondsPanel';
import MembershipPanel from '@/components/MembershipPanel';
import VerificationPanel from '@/components/VerificationPanel';
import PurchaseRequestsPanel from '@/components/PurchaseRequestsPanel';
import ChatControlPanel from '@/components/ChatControlPanel';
import MaintenancePanel from '@/components/MaintenancePanel';
import { useToasts } from '@/hooks/useToasts';
import type { PanelKey } from '@/components/Sidebar';

export default function App() {
  const [authed, setAuthed] = useState(false);
  const [activePanel, setActivePanel] = useState<PanelKey>('coins');
  const { toasts, addToast, removeToast } = useToasts();

  if (!authed) {
    return <Login onLogin={() => setAuthed(true)} />;
  }

  return (
    <Layout
      activePanel={activePanel}
      onNavigate={setActivePanel}
      onLogout={() => setAuthed(false)}
      toasts={toasts}
      removeToast={removeToast}
    >
      {activePanel === 'coins' && <AdminPanel addToast={addToast} />}
      {activePanel === 'diamonds' && <DiamondsPanel addToast={addToast} />}
      {activePanel === 'membership' && <MembershipPanel addToast={addToast} />}
      {activePanel === 'verification' && <VerificationPanel addToast={addToast} />}
      {activePanel === 'orders' && <PurchaseRequestsPanel addToast={addToast} />}
      {activePanel === 'chat' && <ChatControlPanel addToast={addToast} />}
      {activePanel === 'maintenance' && <MaintenancePanel addToast={addToast} />}
    </Layout>
  );
}
